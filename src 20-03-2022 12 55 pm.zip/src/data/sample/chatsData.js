var chatsData = [
    {
        id : 'c1',
        name : "We are Inevitables👶🏻",
        lastChatOn : 'yesterday',
        group : true,
        chatMember : 'Sai Teja',
        lastMessage : '# Sticker',
        chatMuted : true,
        notifications : 4
    },
    {
        id: 'c2',
        name : "chat2",
        lastChatOn : '25/08/2021',
        group : false,
        chatMember : 'chat2',
        lastMessage : 'checking',
        chatMuted : false,
        notifications : 1 
    }
]
export default chatsData;