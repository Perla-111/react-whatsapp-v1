import React from 'react';
import './homepage.css';
import {withRouter} from 'react-router-dom';

import Footer from '../footer/footer';
import ChatTiles from './body';
import Header from './header';

const HomePage =() => {

        return(
            <div className="HomePage">

                    <Header  />
                    <ChatTiles />
                    <Footer />

            </div>
        );
    
}


export default withRouter(HomePage);