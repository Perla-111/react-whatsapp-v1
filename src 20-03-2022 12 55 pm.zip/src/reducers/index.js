import {combineReducers} from 'redux';
//import products from './productReducer';
//import users from './userReducer';
import states from './stateReducer';

const rootReducer = combineReducers({
  //products,
  //users,
 states
});

export default rootReducer;