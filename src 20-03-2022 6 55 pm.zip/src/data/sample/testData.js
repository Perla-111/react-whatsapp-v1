var testData = {
    c1 : [
        {
            msg : "Hii",
            msgType : "sent"
        },
        {
            msg : "all(group)",
            msgType : "sent"
        },
        {
            msg : "Hii Perla",
            msgType : "received"
        },
        {
            msg : "checking looks like something phishy",
            msgType : "sent"
        },
        {
            msg : "I am fine",
            msgType : "received"
        }
    
    ], 
    c2 : [
        {
            msg : "Hii",
            msgType : "sent"
        },
        {
            msg : "chat2",
            msgType : "sent"
        }
    
    ]}
export default testData;
