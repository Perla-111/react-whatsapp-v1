var restchatsData = [
    {
        uid : 'c1',
        name : "Ram",
        lastChatOn : 'yesterday',
        group : false,
        chatMember : 'Sai Teja',
        lastMessage : 'thank you',
        chatMuted : true,
        notifications : 0,
        sent : true
    },
    {
        uid: 'c2',
        name : "Surya Kumar",
        lastChatOn : '25/03/2022',
        group : false,
        chatMember : 'chat2',
        lastMessage : 'nice to hear that',
        chatMuted : false,
        notifications : 1 ,
        sent : false
    },
    {
        uid : 'c1',
        name : "We are Inevitables👶🏻",
        lastChatOn : 'yesterday',
        group : true,
        chatMember : 'Sai Teja',
        lastMessage : '# Sticker',
        chatMuted : false,
        notifications : 4,
        sent : false
        
    },
    {
        uid: 'c2',
        name : "Surya Pvp",
        lastChatOn : '25/03/2022',
        group : false,
        chatMember : 'chat2',
        lastMessage : 'checking',
        chatMuted : false,
        notifications : 0,
        sent : true
    },
    {
        uid : 'c1',
        name : "Pooja",
        lastChatOn : 'yesterday',
        group : false,
        chatMember : 'Sai Teja',
        lastMessage : '# Sticker',
        chatMuted : true,
        notifications : 2,
        sent : false
    },
    {
        uid: 'c2',
        name : "Mohan gaytri",
        lastChatOn : '25/03/2022',
        group : false,
        chatMember : 'chat2',
        lastMessage : 'ok bubbye',
        chatMuted : false,
        notifications : 0,
        sent : false
    },
    {
        uid : 'c1',
        name : "Ramesh techy",
        lastChatOn : 'yesterday',
        group : false,
        chatMember : 'Sai Teja',
        lastMessage : '# Sticker',
        chatMuted : true,
        notifications : 0,
        sent : false
    },
    {
        uid: 'c2',
        name : "Deepthi",
        lastChatOn : '25/03/2022',
        group : false,
        chatMember : 'chat2',
        lastMessage : 'checking',
        chatMuted : false,
        notifications : 0,
        sent : true
    }
]
export default restchatsData;